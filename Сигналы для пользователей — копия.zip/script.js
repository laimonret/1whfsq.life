// === ПАРОЛЬ ЗАЩИТЫ ===
document.addEventListener('DOMContentLoaded', () => {
    const correctPassword = "$AbuzzLegend$";
    const passwordModal = document.getElementById('passwordModal');
    const passwordForm = document.getElementById('passwordForm');
    const passwordInput = document.getElementById('passwordInput');
    const passwordError = document.getElementById('passwordError');

    // Проверяем, был ли уже введён пароль
    if (localStorage.getItem('accessGranted') === 'true') {
        passwordModal.style.display = 'none';
        return;
    }

    // Показываем модалку
    passwordModal.style.display = 'flex';

    passwordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const entered = passwordInput.value.trim();
        if (entered === correctPassword) {
            localStorage.setItem('accessGranted', 'true');
            passwordModal.style.display = 'none';
        } else {
            passwordError.textContent = "Неверный пароль!";
            passwordInput.value = '';
            passwordInput.focus();
        }
    });
});

// === ОСТАЛЬНОЙ КОД БЕЗ ИЗМЕНЕНИЙ ===

// Автоматический слайдер
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;
function showSlide(index) {
    slides.forEach(slide => slide.classList.remove('active'));
    slides[index].classList.add('active');
}
function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    showSlide(currentSlide);
}
function prevSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    showSlide(currentSlide);
}
setInterval(nextSlide, 5000);
document.querySelector('.next-btn').addEventListener('click', nextSlide);
document.querySelector('.prev-btn').addEventListener('click', prevSlide);

// Меню с вкладками
document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
        const toggle = item.getAttribute('data-toggle');
        const submenu = document.getElementById(toggle + '-submenu');
        const isExpanded = item.classList.contains('active');
        document.querySelectorAll('.menu-item').forEach(el => {
            el.classList.remove('active');
        });
        document.querySelectorAll('.submenu').forEach(el => {
            el.style.display = 'none';
        });
        if (!isExpanded) {
            item.classList.add('active');
            if (submenu) submenu.style.display = 'block';
        }
    });
});

// Кнопка скрытия панели
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const width = sidebar.style.width === '100px' ? '250px' : '100px';
    sidebar.style.width = width;
    const btn = document.querySelector('.toggle-btn');
    btn.textContent = width === '250px' ? '<<' : '>>';
}

// === ПРОФИЛЬ ===
const userSection = document.getElementById('userSection');
const profileModal = document.getElementById('profileModal');
const closeModalBtn = document.querySelector('.close');
const form = document.getElementById('profileForm');
const userNameInput = document.getElementById('userName');
const userIdInput = document.getElementById('userIdInput');
const userAvatarInput = document.getElementById('userAvatarInput');
const avatarPreview = document.getElementById('avatarPreview');
const usernameDisplay = document.getElementById('username');
const userIdDisplay = document.getElementById('userId');
const userAvatarImg = document.getElementById('userAvatar');

document.addEventListener('DOMContentLoaded', () => {
    const savedName = localStorage.getItem('userName') || 'Merin Copy';
    const savedId = localStorage.getItem('userId') || 'Enter your id';
    const savedAvatarUrl = localStorage.getItem('userAvatarUrl');
    usernameDisplay.textContent = savedName;
    userIdDisplay.textContent = `ID: ${savedId}`;
    if (savedAvatarUrl) {
        userAvatarImg.src = savedAvatarUrl;
    }
    userNameInput.value = savedName;
    userIdInput.value = savedId;
});

userSection.addEventListener('click', () => {
    profileModal.style.display = 'flex';
});

closeModalBtn.addEventListener('click', () => {
    profileModal.style.display = 'none';
});

window.addEventListener('click', (event) => {
    if (event.target === profileModal) {
        profileModal.style.display = 'none';
    }
});

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = userNameInput.value.trim();
    const id = userIdInput.value.trim();
    let avatarUrl = null;
    if (userAvatarInput.files && userAvatarInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            avatarUrl = e.target.result;
            localStorage.setItem('userAvatarUrl', avatarUrl);
            userAvatarImg.src = avatarUrl;
            avatarPreview.innerHTML = `<img src="${avatarUrl}" alt="Preview">`;
        };
        reader.readAsDataURL(userAvatarInput.files[0]);
    }
    localStorage.setItem('userName', name);
    localStorage.setItem('userId', id);
    usernameDisplay.textContent = name;
    userIdDisplay.textContent = `ID: ${id}`;
    profileModal.style.display = 'none';
    userAvatarInput.value = '';
});

userAvatarInput.addEventListener('change', () => {
    if (userAvatarInput.files && userAvatarInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            avatarPreview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        };
        reader.readAsDataURL(userAvatarInput.files[0]);
    } else {
        avatarPreview.innerHTML = '';
    }
});

// === ПОПОЛНЕНИЕ БАЛАНСА ===
function openDepositModal() {
    document.getElementById('depositModal').style.display = 'flex';
}
function closeDepositModal() {
    document.getElementById('depositModal').style.display = 'none';
}

window.addEventListener('click', (event) => {
    const modal = document.getElementById('depositModal');
    if (event.target === modal) {
        closeDepositModal();
    }
});

document.getElementById('depositForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const currency = document.getElementById('currency').value;
    const amount = parseFloat(document.getElementById('amount').value);
    if (isNaN(amount) || amount <= 0) {
        alert("Введите корректную сумму");
        return;
    }
    localStorage.setItem('balanceCurrency', currency);
    localStorage.setItem('balanceAmount', amount);
    updateBalanceDisplay();
    closeDepositModal();
    this.reset();
});

function updateBalanceDisplay() {
    const currency = localStorage.getItem('balanceCurrency') || 'USDT';
    const amount = parseFloat(localStorage.getItem('balanceAmount')) || 0;
    const balanceValue = document.querySelector('.balance-value');
    const currencySelect = document.querySelector('.currency-select span');
    balanceValue.textContent = Math.floor(amount);
    currencySelect.textContent = currency;
}

document.addEventListener('DOMContentLoaded', () => {
    updateBalanceDisplay();
});