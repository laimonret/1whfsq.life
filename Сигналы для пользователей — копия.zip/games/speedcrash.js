// Получаем элементы
const playBtn = document.getElementById('playBtn');
const backBtn = document.getElementById('backBtn');
const randomNumberDisplay = document.getElementById('randomNumberDisplay');
const timerProgress = document.getElementById('timerProgress');
const timerBar = document.getElementById('timerBar');
const numberOverlay = document.getElementById('numberOverlay');
let isPlaying = false;

// Функция генерации случайного числа с повышенной вероятностью для 1.00–6.00
function generateWeightedRandomNumber() {
    if (Math.random() < 0.7) {
        return (Math.random() * (6.00 - 1.00) + 1.00).toFixed(2);
    } else {
        return (Math.random() * (25.05 - 6.01) + 6.01).toFixed(2);
    }
}

// Функция обновления числа с плавной анимацией
function updateNumber() {
    const randomNum = generateWeightedRandomNumber();
    if (numberOverlay.classList.contains('visible')) {
        numberOverlay.classList.remove('visible');
        numberOverlay.classList.add('fade-out');
        setTimeout(() => {
            showNewNumber(randomNum);
        }, 400);
    } else {
        showNewNumber(randomNum);
    }
}

// Вспомогательная функция для показа нового числа
function showNewNumber(value) {
    numberOverlay.textContent = `x${value}`;
    numberOverlay.classList.remove('fade-out');
    numberOverlay.classList.add('visible');

    // Усиливаем анимацию колеса при появлении числа
    const wheelSpokes = randomNumberDisplay.querySelector('.wheel-spokes');
    wheelSpokes.style.animation = 'none';
    void wheelSpokes.offsetWidth;
    wheelSpokes.style.animation = 'rotateWheel 2s ease-out infinite';
}

// Функция запуска таймера — ИЗМЕНЕНО С 15000 НА 7000 МС (7 СЕКУНД)
function startTimer(callback) {
    timerBar.style.display = 'block';
    timerProgress.style.transition = 'none';
    timerProgress.style.width = '100%';
    void timerProgress.offsetWidth;
    timerProgress.style.transition = 'width 7s linear';
    timerProgress.style.width = '0%';

    // Усиливаем анимацию колеса во время таймера
    const wheelSpokes = randomNumberDisplay.querySelector('.wheel-spokes');
    wheelSpokes.style.animation = 'rotateWheel 1s linear infinite';

    setTimeout(() => {
        callback();
        // Возвращаем нормальную скорость вращения
        wheelSpokes.style.animation = 'rotateWheel 6s linear infinite';
    }, 7000);
}

// Обработчик клика на кнопку "Play"
playBtn.addEventListener('click', () => {
    if (isPlaying) return;
    isPlaying = true;
    playBtn.disabled = true;
    startTimer(() => {
        updateNumber();
        isPlaying = false;
        playBtn.disabled = false;
    });
});

// Обработчик кнопки "Back"
backBtn.addEventListener('click', () => {
    window.location.href = '../index.html';
});