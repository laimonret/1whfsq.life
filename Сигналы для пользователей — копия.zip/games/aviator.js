// Получаем элементы
const playBtn = document.getElementById('playBtn');
const backBtn = document.getElementById('backBtn');
const randomNumberDisplay = document.getElementById('randomNumberDisplay');
const propellerBlades = document.querySelector('.propeller-blades');
const timerProgress = document.getElementById('timerProgress');
const timerBar = document.getElementById('timerBar');
const numberOverlay = document.getElementById('numberOverlay');
let isPlaying = false;

// Функция генерации случайного числа с повышенной вероятностью для 1.00–6.00
function generateWeightedRandomNumber() {
    if (Math.random() < 0.7) {
        return (Math.random() * (6.00 - 1.00) + 1.00).toFixed(2);
    } else {
        return (Math.random() * (25.05 - 6.01) + 6.01).toFixed(2);
    }
}

// Функция обновления числа с плавной анимацией
function updateNumber() {
    const randomNum = generateWeightedRandomNumber();
    if (numberOverlay.classList.contains('visible')) {
        numberOverlay.classList.remove('visible');
        numberOverlay.classList.add('fade-out');
        setTimeout(() => {
            showNewNumber(randomNum);
        }, 400);
    } else {
        showNewNumber(randomNum);
    }
}

// Вспомогательная функция для показа нового числа
function showNewNumber(value) {
    numberOverlay.textContent = `x${value}`;
    numberOverlay.classList.remove('fade-out');
    numberOverlay.classList.add('visible');
    // Красный градиент
    randomNumberDisplay.style.background = `linear-gradient(135deg, hsl(${0 + Math.random() * 10}, 100%, 50%), hsl(${0 + Math.random() * 20}, 80%, 40%))`;
    // Меняем скорость вращения пропеллера случайным образом
    const speeds = ['fast', 'normal', 'slow'];
    const randomSpeed = speeds[Math.floor(Math.random() * speeds.length)];
    // Удаляем все классы скорости
    propellerBlades.classList.remove('fast', 'slow');
    // Добавляем новый класс скорости, если он не 'normal'
    if (randomSpeed !== 'normal') {
        propellerBlades.classList.add(randomSpeed);
    }
    // Добавляем эффект "турбо" с вероятностью 30%
    if (parseFloat(value) > 5.00 && Math.random() < 0.3) {
        propellerBlades.classList.add('fast');
        document.querySelector('.propeller-glow').style.animation = 'pulseGlow 0.5s infinite alternate';
    } else {
        document.querySelector('.propeller-glow').style.animation = 'pulseGlow 2s infinite alternate';
    }
}

// Функция запуска таймера — 7 секунд
function startTimer(callback) {
    timerBar.style.display = 'block';
    timerProgress.style.transition = 'none';
    timerProgress.style.width = '100%';
    void timerProgress.offsetWidth;
    timerProgress.style.transition = 'width 7s linear';
    timerProgress.style.width = '0%';
    setTimeout(() => {
        callback();
    }, 7000);
}

// Обработчик клика на кнопку "Play"
playBtn.addEventListener('click', () => {
    if (isPlaying) return;
    isPlaying = true;
    playBtn.disabled = true;
    // Запускаем анимацию пропеллера при нажатии
    propellerBlades.classList.add('fast');
    startTimer(() => {
        updateNumber();
        isPlaying = false;
        playBtn.disabled = false;
        // Возвращаем нормальную скорость после завершения
        setTimeout(() => {
            propellerBlades.classList.remove('fast');
        }, 1000);
    });
});

// Обработчик кнопки "Back"
backBtn.addEventListener('click', () => {
    window.location.href = '../index.html';
});