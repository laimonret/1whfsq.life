// Получаем элементы
const playBtn = document.getElementById('playBtn');
const backBtn = document.getElementById('backBtn');
const randomNumberDisplay = document.getElementById('randomNumberDisplay');
const propellerBlades = document.querySelector('.propeller-blades');
const timerProgress = document.getElementById('timerProgress');
const timerBar = document.getElementById('timerBar');
const numberOverlay = document.getElementById('numberOverlay');
let isPlaying = false;

// Функция генерации случайного ЦЕЛОГО числа от 1 до 10
// Числа 1-5 появляются с 70% вероятностью, 6-10 — с 30%
function generateWeightedRandomNumber() {
    if (Math.random() < 0.7) {
        // Числа от 1 до 5 (чаще)
        return Math.floor(Math.random() * 5) + 1;
    } else {
        // Числа от 6 до 10 (реже)
        return Math.floor(Math.random() * 5) + 6;
    }
}

// Функция обновления числа с плавной анимацией
function updateNumber() {
    const randomNum = generateWeightedRandomNumber();
    if (numberOverlay.classList.contains('visible')) {
        numberOverlay.classList.remove('visible');
        numberOverlay.classList.add('fade-out');
        setTimeout(() => {
            showNewNumber(randomNum);
        }, 400);
    } else {
        showNewNumber(randomNum);
    }
}

// Вспомогательная функция для показа нового числа
function showNewNumber(value) {
    // ИЗМЕНЕНО: Убран "x", только число
    numberOverlay.textContent = value;
    numberOverlay.classList.remove('fade-out');
    numberOverlay.classList.add('visible');

    // ИЗМЕНЕНО: Только голубо-синие градиенты
    randomNumberDisplay.style.background = `linear-gradient(135deg, hsl(${210 + Math.random() * 30}, 70%, 60%), hsl(${200 + Math.random() * 40}, 80%, 70%))`;

    // Меняем скорость вращения пропеллера случайным образом
    const speeds = ['fast', 'normal', 'slow'];
    const randomSpeed = speeds[Math.floor(Math.random() * speeds.length)];

    // Удаляем все классы скорости
    propellerBlades.classList.remove('fast', 'slow');

    // Добавляем новый класс скорости, если он не 'normal'
    if (randomSpeed !== 'normal') {
        propellerBlades.classList.add(randomSpeed);
    }

    // Добавляем эффект "турбо" с вероятностью 30%
    if (value > 5 && Math.random() < 0.3) {
        propellerBlades.classList.add('fast');
        document.querySelector('.propeller-glow').style.animation = 'pulseGlow 0.5s infinite alternate';
    } else {
        document.querySelector('.propeller-glow').style.animation = 'pulseGlow 2s infinite alternate';
    }
}

// Функция запуска таймера — 7000 МС (7 СЕКУНД)
function startTimer(callback) {
    timerBar.style.display = 'block';
    timerProgress.style.transition = 'none';
    timerProgress.style.width = '100%';
    void timerProgress.offsetWidth;
    timerProgress.style.transition = 'width 7s linear';
    timerProgress.style.width = '0%';
    setTimeout(() => {
        callback();
    }, 7000);
}

// Обработчик клика на кнопку "Play"
playBtn.addEventListener('click', () => {
    if (isPlaying) return;
    isPlaying = true;
    playBtn.disabled = true;

    // Запускаем анимацию пропеллера при нажатии
    propellerBlades.classList.add('fast');

    startTimer(() => {
        updateNumber();
        isPlaying = false;
        playBtn.disabled = false;

        // Возвращаем нормальную скорость после завершения
        setTimeout(() => {
            propellerBlades.classList.remove('fast');
        }, 1000);
    });
});

// Обработчик кнопки "Back"
backBtn.addEventListener('click', () => {
    window.location.href = '../index.html';
});